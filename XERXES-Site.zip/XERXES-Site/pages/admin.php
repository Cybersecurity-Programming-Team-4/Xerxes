<?php include("head.php"); ?>

<html>

<body>
	<!-- #wrapper -->
    <div id="wrapper">
		
		<?php include("nav.php"); ?>

		<!-- #page-wrapper -->		
		<div id="page-wrapper">
		<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Request ID</th>
                                            <th>User</th>
                                            <th>IP</th>
                                            <th>Time</th>
											<th>Accept</th>
											<th>Deny</th>
											
                                        </tr>
                                    </thead>
									
						<?php
						
						$directory = mysqli_query($conn,"SELECT * FROM SCAN_REQUESTS");
						while($row = mysqli_fetch_array($directory)) {
						?>
                                    <tbody>
                                        <tr>
											<td><a href = <?php echo $url;?> ><?php echo $row['IP_ADDRESS']?></a></td>
                                            <td><?php echo $row['REQUEST_ID']?></td>
                                            <td><?php echo $row['REQUESTER_NAME']?></td>
                                            <td><?php echo $row['TARGET_IP']?></td>
											<td><?php echo $row['SUBMISSION_TIME']?></td>
											<td><button>Accept</button></td>
											<td><button>Deny</button></td>
                                        </tr>
                                    </tbody>
						<?php
						}
						?>
						
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
		<!-- /#page-wrapper -->
		</div>
		
	<!-- /#wrapper -->
	</div>

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>

	
</body>

</html>