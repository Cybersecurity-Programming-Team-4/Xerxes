

<body>
		<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">XERXES - Wordpress Vulnerability Scanner</a>
            </div>
			<br></br>
            <!-- /.navbar-header -->
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search IP...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li>
                            <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
						<?php
						if($_SESSION["level"] = 1){
						echo 	'<li>
									<a href="admin.php"><i class="fa fa-edit fa-fw"></i> Admin Control Panel</a>
								</li>';	
						}
						?>
                        <li>
                            <a href="directory.php"><i class="fa fa-table fa-fw"></i> Scan Directory</a>
                        </li>
						  <li>
                            <a href="search.php"><i class="fa fa-table fa-fw"></i> Advanced Search</a>
                        </li>
						
                        <li>
                            <a href="submit.php"><i class="fa fa-edit fa-fw"></i> Submit Scan</a>
                        </li>
						<li>
                            <a href="logout.php"><i class="fa fa-edit fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
</body>