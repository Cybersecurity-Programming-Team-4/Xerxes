<?php include("head.php"); ?>

<html>

<?php

if($_SERVER["REQUEST_METHOD"] == "GET") {
	if ($_GET["ip"]){
		if(filter_var($_GET["ip"],FILTER_VALIDATE_IP)){
			$ip = $_GET["ip"];
			$query = mysqli_query($conn,"SELECT * FROM SITE_INFO WHERE IP_ADDRESS = '$ip' LIMIT 1");
			if($query->num_rows == 1){
				echo "test";
				$query_v = mysqli_query($conn,"SELECT * FROM SITE_VULNERABILITIES WHERE IP_ADDRESS = '$ip' LIMIT 1");
				$query_wi = mysqli_query($conn,"SELECT * FROM WHOIS_INFO WHERE IP_ADDRESS = '$ip' LIMIT 1");
				
				$ip_info = mysqli_fetch_row($query);
				$ip_info_v = mysqli_fetch_row($query_v);
				$ip_info_wi = mysqli_fetch_row($query_wi);
				
			}else{
			}
		}else{
		}
	}else{
	}
}

?>

<body>

	<!-- #wrapper -->
    <div id="wrapper">
		
		<?php include("nav.php"); ?>

		<!-- #page-wrapper -->		
		<div id="page-wrapper">
		
		
		<div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Detail View</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            IP: <?php echo $ip_info[0];?>, Scanned  <?php echo $ip_info[6];?>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
								<h class="small-header"> <u>SITE INFO</u><br/> </h>
								<h>Hostname: <?php echo $ip_info[1];?> <br/></h>
								<h>IP Version: <?php echo $ip_info[2];?><br/></h>
								<h>CMS Type: <?php echo $ip_info[4];?><br/></h>
								<h>Overall Vulnerability Score: <?php echo $ip_info[5];?><br/></h>
								<h class="small-header"> <u>VULNERABILITY REPORT</u><br/> </h>
								<?php
								while($row = mysqli_fetch_array($query_v)) {
								?>
								
								<tbody>
                                        <tr>
                                            <td><?php echo $row['TYPE']?></td>
											<td><?php echo $row['DESCRIPTION']?></td>
										</tr>
                                    </tbody>
								<?php
								}
								if (empty(mysqli_fetch_array($query_v))){
									echo "No vulnerabilities detected. <br/>";
								}
								?>
								
								<h class="small-header"> <u>WHOIS</u><br/> </h>
								<h>Organization: <?php echo $ip_info_wi[1];?> <br/></h>
								<h>Country: <?php echo $ip_info_wi[2];?><br/></h>
								<h>State: <?php echo $ip_info_wi[3];?><br/></h>
								<h>City: <?php echo $ip_info_wi[4];?><br/></h>
								<h>Address: <?php echo $ip_info_wi[5];?><br/></h>
								<h>Description: <?php echo $ip_info_wi[6];?><br/></h>
								<h>Contact: <?php echo $ip_info_wi[7];?><br/></h>
								
								
								
								</div>
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
		
		
		<!-- /#page-wrapper -->
		</div>
		
	<!-- /#wrapper -->
	</div>

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>

	
</body>

</html>