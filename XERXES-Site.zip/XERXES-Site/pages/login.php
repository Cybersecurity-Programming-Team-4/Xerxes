<!DOCTYPE html>
<html lang="en">

<?php include("head.php"); ?>


<body>

<?php

if($_SERVER["REQUEST_METHOD"] == "POST") {
	$user = filter_var($_POST["username"]);
	$pass = filter_var($_POST["password"]);
	$query = mysqli_query($conn,"SELECT PASSWORD FROM USERS WHERE USERNAME = '$user' LIMIT 1");
	if($query){
		$hash = mysqli_fetch_array($query);
		
		if(password_verify($pass,$hash[0])){
			$_SESSION["user"] = $user;
			$query_lv = mysqli_query($conn,"SELECT LEVEL FROM USERS WHERE USERNAME = '$user' LIMIT 1");
			$lv = mysqli_fetch_array($query);
			$_SESSION["level"] = $lv;
			header("Location:index.php");
		} else {
			$_SESSION['error'] = "Invalid username/password";
		}	
	}else{
		$_SESSION['error'] = "Invalid username/password";
	}
	
}
?>


    <div class="container">

	<div class="row">
			<h class="big-header">XERXES</h>
			<h class="little-header">SERIES X-9000SC</h>
            <div class="col-md-4 col-md-offset-4">
			<div>

			</div>
				<div class="login-panel panel panel-default">
				
                    <div class="panel-heading">
                        <h3 class="panel-title">Please Sign In</h3>
                    </div>
                    <div class="panel-body">
                        <form method ="post" action = "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Username" id = "username" name="username" type= "text" value="" autofocus >
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" id = "password" name="password" type= "password" value="" >
                                <?php
								if(isset($_SESSION['error'])){
									echo $_SESSION['error'];
									$_SESSION['error'] = NULL;
								}
								?>
								</div>
								<div >
									<button class="form-control" type="submit" name="submit" value="Submit">Submit</button>
								</div>
						   </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
