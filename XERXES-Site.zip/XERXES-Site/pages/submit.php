<?php include("head.php"); ?>

<html>

<body>

<?php
	if($_SERVER["REQUEST_METHOD"] == "POST") {
		if(isset($_POST["host"]) && ($_POST["host"] != '')){
		$url = $_POST["host"];
			if(parse_url($url)){
				
				$ip = gethostbyname($url);
				if($ip != $url){
					$_SESSION["response"] = "The IP address for " . $url . " is " . $ip;
				}else{
					$_SESSION["response"] = "Error determining hostname.";
				}
			}else{
				$_SESSION["response"] = "Error determining hostname.";
			}
		}
		$now = time();
		if(isset($_POST["ip"]) && ($_POST["ip"] != '')){
			if (filter_var($_POST["ip"], FILTER_VALIDATE_IP)) {
				$sql = 'INSERT INTO SCAN_REQUESTS (REQUESTER_NAME, TARGET_IP, SUBMISSION_TIME, APPROVAL_STATUS) VALUES ("{$_SESSION["user"]}", "{$_POST["ip"]}", "{$now}", "No")';
				if ($conn->query($sql) === TRUE) {
					$_SESSION["response_ip"] = "Request submitted";
				} else {
					$_SESSION["response_ip"] = "Error in submitting request";
				}
			}else{
				$_SESSION["response_ip"] = "Error in IP address.";
			}
		}
	}
?>

	<!-- #wrapper -->
    <div id="wrapper">
		
		<?php include("nav.php"); ?>

		<!-- #page-wrapper -->		
		<div id="page-wrapper">
		
		
			<div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Submit Scan Request</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Submission Panel
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Hostname Lookup</label>
											
											<form method ="post" action = "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
												<input class="form-control" type="text" name="host" id="host" value="" placeholder="www.example.com">
												<?php
												if(isset($_SESSION["response"])){
													echo $_SESSION["response"];
													unset($_SESSION["response"]);
 												}
												else{
													echo '<p class="help-block">If you do not know the IP address of the website you wish to scan, enter the hostname here.</p>';
												}
												?>
												
												<button type="submit" type="submit" name="submit" class="btn btn-outline btn-primary">Search</button>
											</form>
											
										</div>
                                        <div class="form-group">
                                            <label>IP Address</label>
											<form method ="post" action = "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
											
												<input name = "ip" type = "text" class="form-control" placeholder="0.0.0.0">
											<button name = "submit" type="submit" class="btn btn-outline btn-primary">Submit Request</button>
                                        </div>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
		
		<!-- /#page-wrapper -->
		</div>
		
	<!-- /#wrapper -->
	</div>

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>